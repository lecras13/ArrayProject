package com.epam.task4.view.enums;

public enum PrintType {
    CONSOLEPRINTER,
    FILEPRINTER,
    TEST
}
