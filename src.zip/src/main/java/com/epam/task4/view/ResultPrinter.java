package com.epam.task4.view;

public interface ResultPrinter {
    void print(String result);
}
