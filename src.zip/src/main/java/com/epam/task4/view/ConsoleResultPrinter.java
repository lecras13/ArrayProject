package com.epam.task4.view;

public class ConsoleResultPrinter implements ResultPrinter {
    public void print(final String result) {
        System.out.println(result);
    }
}
