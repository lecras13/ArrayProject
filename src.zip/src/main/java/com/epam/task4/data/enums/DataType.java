package com.epam.task4.data.enums;

public enum DataType {
    CONSOLE,
    FILE,
    GENERATE,
    TEST
}
