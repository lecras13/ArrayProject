package com.epam.task4.data;

import com.epam.task4.entity.Array;

public interface DataAcquirer {
    Array getArray();
}
